import 'package:flutter/material.dart';

void main() {
  runApp(SalaryCalculatorApp());
}

class SalaryCalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حساب الراتب',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SalaryCalculatorScreen(),
    );
  }
}

class SalaryCalculatorScreen extends StatefulWidget {
  @override
  _SalaryCalculatorScreenState createState() => _SalaryCalculatorScreenState();
}

class _SalaryCalculatorScreenState extends State<SalaryCalculatorScreen> {
  final TextEditingController baseSalaryController = TextEditingController();
  final TextEditingController allowanceController = TextEditingController();
  final TextEditingController bonusController = TextEditingController();
  final TextEditingController penaltyController = TextEditingController();
  final TextEditingController delayController = TextEditingController();

  double finalSalary = 0.0;

  void calculateSalary() {
    double baseSalary = double.tryParse(baseSalaryController.text) ?? 0.0;
    double allowance = double.tryParse(allowanceController.text) ?? 0.0;
    double bonus = double.tryParse(bonusController.text) ?? 0.0;
    double penalty = double.tryParse(penaltyController.text) ?? 0.0;
    double delay = double.tryParse(delayController.text) ?? 0.0;

    // خصم التأخير يمكن أن يكون قيمة محددة لكل ساعة (مثلاً 50)
    double deductionPerHour = 50.0;
    double totalDeduction = delay * deductionPerHour;

    setState(() {
      finalSalary = baseSalary + allowance + bonus - penalty - totalDeduction;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('حساب الراتب'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: baseSalaryController,
              decoration: InputDecoration(labelText: 'الراتب الأساسي'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: allowanceController,
              decoration: InputDecoration(labelText: 'العلاوة'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: bonusController,
              decoration: InputDecoration(labelText: 'المكافأة'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: penaltyController,
              decoration: InputDecoration(labelText: 'العقوبة'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: delayController,
              decoration: InputDecoration(labelText: 'التأخير (عدد الساعات)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateSalary,
              child: Text('احسب الراتب'),
            ),
            SizedBox(height: 20),
            Text(
              'الراتب النهائي: \$${finalSalary.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
